from flask import Flask, request, jsonify, send_file
import matplotlib.pyplot as plt
import pysondb as pb
import io

database = pb.getDb("static/data.json")

app = Flask(__name__)


@app.route('/', methods=['GET'])
def hello_world():
    return jsonify(database.getAll())


@app.route('/data', methods=['POST'])
def save_data():
    data = request.get_json()
    db_item = {
        "value": data.get("value"),
        "timestamp": data.get("timestamp"),
        "device_id": data.get("device_id")
    }
    database.add(db_item)
    return "Successfully added", 204


def get_color_for_aqi(aqi):
    if 0 <= aqi <= 50:
        return 'green'
    elif 51 <= aqi <= 100:
        return 'yellow'
    elif 101 <= aqi <= 150:
        return 'orange'
    elif 151 <= aqi <= 200:
        return 'red'
    else:
        return 'gray'


def create_aqi_stem_plot(aqi_values, colors):
    fig, ax = plt.subplots()

    for i, aqi in enumerate(aqi_values):
        color = colors[i]
        ax.stem(i, aqi, linefmt=f'{color}', markerfmt=f'{color}', basefmt=' ')

    ax.set_title('Air Quality Data')
    ax.set_xlabel('Data Point')
    ax.set_ylabel('AQI Value')
    ax.set_xticks(range(len(aqi_values)))
    ax.set_xticklabels([str(i) for i in range(1, len(aqi_values) + 1)])
    ax.grid(True)


def filter_data_by_sensor(data, sensor_id):
    return [entry for entry in data if entry["device_id"] == sensor_id]


@app.route('/graph/<aqi_sensor_id>', methods=['GET'])
def generate_aqi_graph(aqi_sensor_id):
    aqi_data = database.getAll()

    aqi_data_for_sensor = filter_data_by_sensor(aqi_data, aqi_sensor_id)

    if not aqi_data_for_sensor:
        return jsonify({"error": "Sensor ID not found"}, 404)

    aqi_data_for_sensor.sort(key=lambda entry: entry['timestamp'])

    aqi_values = [entry['value'] for entry in aqi_data_for_sensor]
    colors = [get_color_for_aqi(aqi) for aqi in aqi_values]

    plt.clf()
    create_aqi_stem_plot(aqi_values, colors)

    img_buffer = io.BytesIO()
    plt.savefig(img_buffer, format='png')
    img_buffer.seek(0)

    return send_file(img_buffer, mimetype='image/png')


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
