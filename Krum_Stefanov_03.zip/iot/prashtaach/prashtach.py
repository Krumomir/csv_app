import threading
import random
import time
import json
import requests

server_url = 'http://volumes-cntr:5000/data'
num_sensors = 3


def simulate_sensor(sensor_id):
    while True:
        data = {
            "value": random.uniform(10, 200),
            "timestamp": time.time(),
            "device_id": f"{sensor_id}"
        }

        response = requests.post(server_url, json=data)
        time.sleep(random.uniform(3, 5))


threads = []
for i in range(num_sensors):
    sensor_thread = threading.Thread(target=simulate_sensor, args=(i + 1,))
    threads.append(sensor_thread)
    sensor_thread.start()

for thread in threads:
    thread.join()
